declare module "@/translations/*.json" {
  const value: Record<string, string>
  export default value
}

